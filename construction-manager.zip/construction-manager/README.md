# Construction Project Manager

A step-by-step construction project management app built with React + Vite.
All costs displayed in **Tanzanian Shilling (TZS)**.

## Features
- Project setup (name, location, type, floor area)
- Material quantity calculator with editable unit costs
- Full cost estimate with adjustable contingency
- Team management with editable headcount & daily rates
- Project procedures with cost implications per phase
- Gantt-style phase timeline
- Risk register & quality checklists
- Printable / exportable project summary

---

## Run locally

Make sure you have **Node.js 18+** installed, then:

```bash
npm install
npm run dev
```

Open http://localhost:5173 in your browser.

---

## Deploy to Vercel (recommended — free)

### Option A: Via GitHub (easiest)

1. Create a free account at https://github.com and https://vercel.com
2. Create a new GitHub repository (e.g. `construction-manager`)
3. Upload all these project files to the repository
4. Go to https://vercel.com/new → click **"Import Git Repository"**
5. Select your repository → click **Deploy**
6. Done! Vercel gives you a live URL like `construction-manager.vercel.app`

### Option B: Via Vercel CLI

```bash
npm install -g vercel
vercel
```

Follow the prompts — it auto-detects Vite and deploys in ~1 minute.

---

## Deploy to Netlify (alternative — also free)

### Option A: Drag & drop (no account needed for a quick test)

```bash
npm run build
```

Then drag the generated `dist/` folder to https://app.netlify.com/drop

### Option B: Via GitHub

Same as Vercel Option A above — connect your GitHub repo at https://app.netlify.com/start

Build settings Netlify needs:
- **Build command:** `npm run build`
- **Publish directory:** `dist`

---

## Custom domain

Both Vercel and Netlify let you add a custom domain for free (e.g. `constructionmanager.co.tz`).
Buy the domain from a registrar (Namecheap, Google Domains, etc.) then follow the
DNS setup instructions in your Vercel/Netlify dashboard.

---

## Project structure

```
construction-manager/
├── public/
│   └── favicon.svg
├── src/
│   ├── App.jsx        ← main application
│   ├── main.jsx       ← React entry point
│   └── index.css      ← global styles
├── index.html
├── package.json
├── vite.config.js
└── README.md
```
